// Rodar:  node --test jornada/testes/store.test.mjs
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { criarStore, validar, dataValida, hojeLocal, CHAVE } from '../js/store.js';

const HOJE = '2026-11-05';
const mk = (init) => {                      // localStorage falso
  const d = new Map(Object.entries(init || {}));
  return { d, getItem: k => (d.has(k) ? d.get(k) : null), setItem: (k, v) => { d.set(k, String(v)); }, removeItem: k => d.delete(k) };
};
const novo = (st = mk()) => ({ st, s: criarStore({ storage: st, hoje: () => HOJE }) });
const salvo = st => JSON.parse(st.d.get(CHAVE));

test('1. sem dados: começa com o formato padrão', () => {
  const { s } = novo();
  assert.deepEqual(s.carregar(), { v: 1, aulas: {}, dias: {}, inicio: null, ultima: null });
});

test('2. progresso sobrevive a recarregar (nova instância lê o mesmo storage)', () => {
  const { st, s } = novo();
  s.concluirAula('m01-a01'); s.concluirDia(3); s.registrarInicio(); s.atualizarUltima('m01-a02');
  const s2 = criarStore({ storage: st, hoje: () => HOJE }).carregar();
  assert.deepEqual(s2, { v: 1, aulas: { 'm01-a01': HOJE }, dias: { 3: HOJE }, inicio: HOJE, ultima: 'm01-a02' });
});

test('3. abrir uma aula NÃO a conclui', () => {
  const { st, s } = novo();
  assert.equal(s.atualizarUltima('m02-a03').ok, true);
  assert.deepEqual(salvo(st).aulas, {});
  assert.deepEqual(salvo(st).dias, {});
  assert.equal(s.aulaConcluida('m02-a03'), false);
  assert.equal(salvo(st).ultima, 'm02-a03');
});

test('4. IDs de aula inválidos são recusados e nada é gravado', () => {
  const { st, s } = novo();
  for (const id of ['x', '', 'm11-a01', 'm00-a01', 'm01-a00', 'M01-A01', 'm1-a1', '__proto__', 'm01-a01 ', null, undefined, 5, {}, ['m01-a01']]) {
    assert.equal(s.concluirAula(id).erro, 'id-invalido', String(id));
    assert.equal(s.atualizarUltima(id).erro, 'id-invalido', String(id));
  }
  assert.equal(st.d.has(CHAVE), false);
});

test('5. datas inválidas são recusadas (formato, calendário e futuro)', () => {
  const { s } = novo();
  for (const d of ['2026-02-30', '2026-13-01', '2026-00-10', '05/11/2026', '2026-11-5', 'ontem', '', null, 20261105, '2019-12-31', '2026-11-07', '2099-01-01'])
    assert.equal(s.concluirAula('m01-a01', d).erro, 'data-invalida', String(d));
  assert.equal(s.concluirAula('m01-a01', '2026-11-06').ok, true); // 1 dia à frente é tolerado (fuso)
  assert.equal(dataValida('2024-02-29'), true);   // ano bissexto
  assert.equal(dataValida('2026-02-29'), false);
});

test('6. dia deve ser inteiro de 1 a 30; "12" é aceito e vira chave "12"', () => {
  const { st, s } = novo();
  for (const d of [0, 31, -1, 1.5, NaN, 'abc', '', '012', null, undefined, '31'])
    assert.equal(s.concluirDia(d).erro, 'dia-invalido', String(d));
  assert.equal(s.concluirDia('12').ok, true);
  assert.equal(s.concluirDia(30).ok, true);
  assert.deepEqual(Object.keys(salvo(st).dias).sort(), ['12', '30']);
});

test('7. registrarInicio não sobrescreve um início existente', () => {
  const { st, s } = novo();
  s.registrarInicio('2026-11-01');
  const r = s.registrarInicio('2026-11-05');
  assert.equal(r.jaRegistrado, true);
  assert.equal(salvo(st).inicio, '2026-11-01');
});

test('8. concluir de novo mantém a data original; desmarcar remove', () => {
  const { st, s } = novo();
  s.concluirAula('m01-a01', '2026-11-01'); s.concluirAula('m01-a01', '2026-11-05');
  assert.equal(salvo(st).aulas['m01-a01'], '2026-11-01');
  s.concluirDia(1, '2026-11-01'); s.desmarcarAula('m01-a01'); s.desmarcarDia(1);
  assert.deepEqual(salvo(st).aulas, {}); assert.deepEqual(salvo(st).dias, {});
});

test('9. JSON corrompido: app inicia limpo e o original é guardado em backup', () => {
  const st = mk({ [CHAVE]: '{"v":1,"aulas":{"m01-a01"' });
  const s = criarStore({ storage: st, hoje: () => HOJE });
  assert.deepEqual(s.carregar().aulas, {});
  assert.equal(st.d.get(CHAVE + '-corrompido'), '{"v":1,"aulas":{"m01-a01"');
  assert.equal(s.concluirAula('m01-a01').ok, true);
});

test('10. dados parcialmente inválidos: descarta só o que está errado', () => {
  const bruto = { v: 1, aulas: { 'm01-a01': HOJE, 'm01-a02': '2026-02-30', 'lixo': HOJE, 'm10-a05': 123 },
    dias: { 1: HOJE, 99: HOJE, '07': HOJE, 5: 'ontem' }, inicio: 'xx', ultima: 'm99-a01', extra: 'ignorado' };
  assert.deepEqual(validar(bruto), { v: 1, aulas: { 'm01-a01': HOJE }, dias: { 1: HOJE }, inicio: null, ultima: null });
  for (const x of [null, 'texto', 42, [], true, undefined]) assert.deepEqual(validar(x), validar({}));
});

test('11. segurança: __proto__/constructor no JSON não contamina objetos', () => {
  const st = mk({ [CHAVE]: '{"v":1,"aulas":{"__proto__":"2026-11-05","constructor":"2026-11-05"},"dias":{"__proto__":"2026-11-05"}}' });
  const e = criarStore({ storage: st, hoje: () => HOJE }).carregar();
  assert.deepEqual(e.aulas, {}); assert.deepEqual(e.dias, {});
  assert.equal({}.polluted, undefined);
});

test('12. versão futura (v:2): lê o que reconhece, mas NUNCA regrava', () => {
  const orig = JSON.stringify({ v: 2, aulas: { 'm01-a01': HOJE }, dias: {}, inicio: null, ultima: null, novoCampo: 1 });
  const st = mk({ [CHAVE]: orig });
  const s = criarStore({ storage: st, hoje: () => HOJE });
  assert.deepEqual(s.carregar().aulas, { 'm01-a01': HOJE });
  assert.equal(s.concluirAula('m01-a02').erro, 'somente-leitura');
  assert.equal(s.somenteLeitura, true);
  assert.equal(st.d.get(CHAVE), orig);            // byte a byte igual
});

test('13. atualização de versão: dados antigos sem "v" são aproveitados e regravados em v:1', () => {
  const st = mk({ [CHAVE]: JSON.stringify({ aulas: { 'm01-a01': '2026-10-30' }, inicio: '2026-10-30' }) });
  const s = criarStore({ storage: st, hoje: () => HOJE });
  assert.equal(s.carregar().aulas['m01-a01'], '2026-10-30');
  s.concluirAula('m01-a02');
  assert.deepEqual(salvo(st), { v: 1, aulas: { 'm01-a01': '2026-10-30', 'm01-a02': HOJE }, dias: {}, inicio: '2026-10-30', ultima: null });
});

test('14. falha ao gravar (cota cheia): não lança, segue em memória, persistente=false', () => {
  const st = mk(); st.setItem = () => { throw new DOMException('cheio', 'QuotaExceededError'); };
  const s = criarStore({ storage: st, hoje: () => HOJE });
  let r; assert.doesNotThrow(() => { r = s.concluirAula('m01-a01'); });
  assert.deepEqual([r.ok, r.persistido, r.erro], [true, false, 'armazenamento']);
  assert.equal(s.aulaConcluida('m01-a01'), true);
  assert.equal(s.persistente, false);
});

test('15. localStorage bloqueado na leitura / inexistente: app funciona em memória', () => {
  const bloqueado = { getItem() { throw new Error('SecurityError'); }, setItem() { throw new Error('SecurityError'); } };
  for (const storage of [bloqueado, null]) {
    const s = criarStore({ storage, hoje: () => HOJE });
    assert.doesNotThrow(() => s.carregar());
    assert.equal(s.concluirDia(2).ok, true);
    assert.equal(s.diaConcluido(2), true);
    assert.equal(s.persistente, false);
  }
});

test('16. o estado devolvido é cópia: alterá-lo não corrompe o store', () => {
  const { s } = novo();
  s.concluirAula('m01-a01');
  const e = s.estado(); e.aulas['m05-a05'] = HOJE; e.inicio = 'lixo';
  assert.deepEqual(s.estado().aulas, { 'm01-a01': HOJE }); assert.equal(s.estado().inicio, null);
});

test('17. hoje = data LOCAL do aparelho, em qualquer fuso (inclusive UTC)', () => {
  // Relógio simulado: no aparelho são 23:30 de 5/nov/2026 (UTC-3), mas em UTC já é 6/nov 02:30.
  // Os getters locais e os UTC divergem de propósito, então o resultado não depende do fuso
  // do ambiente onde o teste roda. Usar toISOString()/getUTC*() faria dar 2026-11-06.
  const relogio = {
    getFullYear: () => 2026, getMonth: () => 10, getDate: () => 5, getHours: () => 23,
    getUTCFullYear: () => 2026, getUTCMonth: () => 10, getUTCDate: () => 6, getUTCHours: () => 2,
    toISOString: () => '2026-11-06T02:30:00.000Z',
  };
  assert.equal(hojeLocal(relogio), '2026-11-05');

  // Caminho real de uso: store SEM injetar "hoje" e com o relógio global simulado.
  const DateReal = globalThis.Date;
  function DateFalso(...a) { return a.length ? new DateReal(...a) : relogio; }
  DateFalso.UTC = DateReal.UTC; DateFalso.now = DateReal.now;
  globalThis.Date = DateFalso;
  try {
    assert.equal(hojeLocal(), '2026-11-05');
    const st = mk();
    const s = criarStore({ storage: st });
    assert.equal(s.concluirAula('m01-a01').ok, true);
    assert.equal(s.concluirDia(1).ok, true);
    assert.equal(s.registrarInicio().ok, true);
    const e = JSON.parse(st.d.get(CHAVE));
    assert.equal(e.aulas['m01-a01'], '2026-11-05');
    assert.equal(e.dias['1'], '2026-11-05');
    assert.equal(e.inicio, '2026-11-05');
  } finally { globalThis.Date = DateReal; }

  // Relógio real: formato válido, com ano/mês/dia iguais aos getters locais.
  const agora = new Date(2026, 0, 31, 23, 59);
  assert.equal(hojeLocal(agora), '2026-01-31');
  assert.equal(dataValida(hojeLocal()), true);
});
