(() => {
  const $ = id => document.getElementById(id);
  const patterns = {
    pulso: {name:'Batida básica', beats:4, slots:['↓','','↓','','↓','','↓',''], words:['1','e','2','e','3','e','4','e'], desc:'Faça uma batida para baixo em cada número: 1, 2, 3 e 4.'},
    alternada: {name:'Para baixo e para cima', beats:4, slots:['↓','↑','↓','↑','↓','↑','↓','↑'], words:['1','e','2','e','3','e','4','e'], desc:'Alterne a mão: desça nos números e suba no “e” entre eles.'},
    balada: {name:'Balada iniciante', beats:4, slots:['↓','','↓','↑','','↑','↓','↑'], words:['1','e','2','e','3','e','4','e'], desc:'Faça os movimentos indicados e mantenha a mão fluindo mesmo nas pausas.'},
    valsa: {name:'Valsa simples', beats:3, slots:['↓','','↓','','↓',''], words:['1','e','2','e','3','e'], desc:'Conte 1, 2, 3. Faça uma batida para baixo em cada tempo.'}
  };
  let selected='pulso', bpm=60, playing=false, timer=null, step=0, audio=null;
  const saved = (()=>{try{return JSON.parse(localStorage.getItem('vd-ritmos')||'{}')}catch{return {}}})();
  if (patterns[saved.pattern]) selected=saved.pattern;
  if (Number.isInteger(saved.bpm) && saved.bpm>=40 && saved.bpm<=160) bpm=saved.bpm;
  const pattern=()=>patterns[selected];
  function render(){
    const p=pattern();
    $('choices').querySelectorAll('button').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.pattern===selected)));
    $('description').textContent=p.desc;
    $('count').innerHTML=Array.from({length:p.beats},(_,i)=>`<span data-beat="${i}">${i+1}</span>`).join('');
    $('moves').innerHTML=p.slots.map((v,i)=>`<div class="move ${v?'':'rest'}" data-step="${i}">${v||'·'}<small>${p.words[i]}</small></div>`).join('');
    $('spoken').textContent='Pronto para começar?';
    clearHighlight();
  }
  function clearHighlight(){document.querySelectorAll('.move,.count span').forEach(e=>e.classList.remove('active'));}
  function save(){try{localStorage.setItem('vd-ritmos',JSON.stringify({pattern:selected,bpm}))}catch{}}
  function setBpm(v){bpm=Math.max(40,Math.min(160,Math.round(v)));$('bpm').value=bpm;$('bpm-value').textContent=bpm;$('tempo-label').textContent=bpm<55?'Bem devagar':bpm<75?'Devagar':bpm<105?'Moderado':bpm<130?'Animado':'Rápido';save();if(playing)restartTimer();}
  function sound(down){if(!audio)return;const t=audio.currentTime,o=audio.createOscillator(),g=audio.createGain();o.type='sine';o.frequency.value=down?1150:820;g.gain.setValueAtTime(.0001,t);g.gain.linearRampToValueAtTime(.24,t+.003);g.gain.exponentialRampToValueAtTime(.0001,t+.055);o.connect(g).connect(audio.destination);o.start(t);o.stop(t+.06);}
  function tick(){const p=pattern(),slot=step%p.slots.length,move=p.slots[slot];clearHighlight();const m=document.querySelector(`[data-step="${slot}"]`);if(m)m.classList.add('active');const beat=Math.floor(slot/2);const c=document.querySelector(`[data-beat="${beat}"]`);if(c)c.classList.add('active');$('spoken').textContent=move==='↓'?'Para baixo':move==='↑'?'Para cima':'Continue o movimento no ar';if(move)sound(move==='↓');step=(step+1)%p.slots.length;}
  function restartTimer(){clearInterval(timer);timer=setInterval(tick,30000/bpm);}
  async function start(){try{audio=audio||new (window.AudioContext||window.webkitAudioContext)();await audio.resume();playing=true;step=0;tick();restartTimer();$('play').textContent='Ⅱ Pausar treino';$('play').setAttribute('aria-pressed','true');}catch(e){$('spoken').textContent='Não foi possível iniciar o áudio neste aparelho.';}}
  function stop(){playing=false;clearInterval(timer);timer=null;clearHighlight();$('play').textContent='▶ Começar treino';$('play').setAttribute('aria-pressed','false');$('spoken').textContent='Treino pausado. Respire e recomece quando quiser.';}
  $('choices').addEventListener('click',e=>{const b=e.target.closest('button[data-pattern]');if(!b)return;if(playing)stop();selected=b.dataset.pattern;save();render();});
  $('bpm').addEventListener('input',e=>setBpm(+e.target.value));
  $('play').addEventListener('click',()=>playing?stop():start());
  document.addEventListener('visibilitychange',()=>{if(document.hidden&&playing)stop()});
  render();setBpm(bpm);
})();
