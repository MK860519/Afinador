import { acordes } from '../acordes/js/dados.js';
import { diagramaAcorde } from '../jornada/js/acordes.js';
(() => {
 const $=id=>document.getElementById(id);
 const porNome=new Map(acordes.map(a=>[a.nome,a]));
 const exercicios={
  facil:{nome:'Começando do zero',sequencia:['Em','Am','Em','Am'],texto:'Comece com Em e Am. São acordes simples para treinar a coordenação dos dedos.'},
  basico:{nome:'Primeiras mudanças',sequencia:['A menor (Am)','C','G','C'],texto:'Treine Am para C e depois C para G. Faça a mudança sem acelerar.'},
  popular:{nome:'Sequência popular',sequencia:['G','D','E menor (Em)','C'],texto:'Pratique uma sequência muito usada em músicas populares. Um acorde por compasso.'},
  desafio:{nome:'Desafio progressivo',sequencia:['A menor (Am)','F','C','G'],texto:'O F simplificado exige mais atenção. Se estiver difícil, volte ao exercício anterior.'}
 };
 // Nomes curtos usados na sequência são convertidos para os nomes exatos do dicionário.
 const aliases={'Em':'E menor (Em)','Am':'A menor (Am)'};
 let selected='facil',bpm=50,playing=false,beat=0,step=0,timer=null,audio=null;
 try{const saved=JSON.parse(localStorage.getItem('vd-troca-acordes')||'{}');if(exercicios[saved.exercicio])selected=saved.exercicio;if(Number.isInteger(saved.bpm)&&saved.bpm>=40&&saved.bpm<=120)bpm=saved.bpm;}catch{}
 const seq=()=>exercicios[selected].sequencia.map(n=>aliases[n]||n);
 function save(){try{localStorage.setItem('vd-troca-acordes',JSON.stringify({exercicio:selected,bpm}));}catch{}}
 function desenhar(id,nome){const a=porNome.get(nome);const alvo=$(id);alvo.replaceChildren();if(a)alvo.append(diagramaAcorde({nome:a.nome,cordas:a.cordas,dedos:a.dedos}));}
 function mostrar(){const s=seq(),atual=s[step%s.length],proximo=s[(step+1)%s.length];$('atual-nome').textContent=atual.replace('E menor (Em)','Em').replace('A menor (Am)','Am');$('proximo-nome').textContent=proximo.replace('E menor (Em)','Em').replace('A menor (Am)','Am');desenhar('atual-diagrama',atual);desenhar('proximo-diagrama',proximo);$('instrucao').textContent=`Toque ${$('atual-nome').textContent} durante 4 tempos. Prepare ${$('proximo-nome').textContent} para a próxima troca.`;}
 function render(){document.querySelectorAll('[data-exercicio]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.exercicio===selected)));$('explicacao').textContent=exercicios[selected].texto;beat=0;step=0;mostrar();contagem();$('fala').textContent='Quando estiver pronto, comece devagar.';}
 function contagem(){[...$('contagem').children].forEach((el,i)=>el.classList.toggle('ativo',i===beat));}
 function som(){if(!audio)return;const t=audio.currentTime,o=audio.createOscillator(),g=audio.createGain();o.type='sine';o.frequency.value=beat===0?1200:850;g.gain.setValueAtTime(.0001,t);g.gain.linearRampToValueAtTime(.18,t+.004);g.gain.exponentialRampToValueAtTime(.0001,t+.07);o.connect(g).connect(audio.destination);o.start(t);o.stop(t+.075);}
 function tick(){som();contagem();$('fala').textContent=beat===0?'Troque ou confirme o acorde!':`Tempo ${beat+1} · mantenha a mão no ritmo.`;beat++;if(beat===4){beat=0;step=(step+1)%seq().length;mostrar();} }
 function iniciarRelogio(){clearInterval(timer);timer=setInterval(tick,60000/bpm);}
 async function start(){try{audio=audio||new(window.AudioContext||window.webkitAudioContext)();await audio.resume();playing=true;beat=0;tick();iniciarRelogio();$('iniciar').textContent='Ⅱ Pausar treino';$('iniciar').setAttribute('aria-pressed','true');}catch{$('fala').textContent='O áudio não pôde iniciar neste aparelho. Verifique as permissões do navegador.';}}
 function stop(){playing=false;clearInterval(timer);timer=null;$('iniciar').textContent='▶ Começar treino';$('iniciar').setAttribute('aria-pressed','false');$('fala').textContent='Treino pausado. Respire e recomece quando quiser.';}
 $('exercicios').addEventListener('click',e=>{const b=e.target.closest('[data-exercicio]');if(!b)return;if(playing)stop();selected=b.dataset.exercicio;save();render();});
 $('bpm').addEventListener('input',e=>{bpm=Math.max(40,Math.min(120,Number(e.target.value)));$('bpm-valor').textContent=bpm;$('tempo-nome').textContent=bpm<55?'Bem devagar':bpm<75?'Devagar':bpm<100?'Moderado':'Rápido';save();if(playing)iniciarRelogio();});
 $('iniciar').addEventListener('click',()=>playing?stop():start());document.addEventListener('visibilitychange',()=>{if(document.hidden&&playing)stop();});
 $('bpm').value=bpm;$('bpm').dispatchEvent(new Event('input'));render();
})();
