import { acordes } from './dados.js';
import { diagramaAcorde } from '../../jornada/js/acordes.js';
const app = document.getElementById('app');
const h = (tag, props, ...children) => {
  const el = document.createElement(tag);
  for (const [key, value] of Object.entries(props || {})) {
    if (value == null || value === false) continue;
    if (key === 'class') el.className = value;
    else if (key === 'text') el.textContent = value;
    else el.setAttribute(key, value);
  }
  el.append(...children.flat().filter(x => x != null));
  return el;
};
let busca = '', familia = 'todos';
const cordasNomes = ['6ª (mais grossa)','5ª','4ª','3ª','2ª','1ª (mais fina)'];
function voltar(){ return h('a',{class:'voltar',href:'../'},'‹ Início'); }
function renderLista(){
 const filtrados = acordes.filter(a => (familia === 'todos' || a.familia === familia) && (a.nome+' '+a.tipo).toLocaleLowerCase('pt-BR').includes(busca.toLocaleLowerCase('pt-BR')));
 const input = h('input',{type:'search',placeholder:'Buscar acorde (ex.: Am, C, G7)…','aria-label':'Buscar acorde',value:busca});
 input.addEventListener('input',()=>{busca=input.value;renderLista();const novo=app.querySelector('input');novo.focus();novo.setSelectionRange(busca.length,busca.length);});
 const filtro = h('select',{'aria-label':'Filtrar família'},...[
  ['todos','Todas as famílias'],['maior','Acordes maiores'],['menor','Acordes menores'],['setima','Acordes com sétima'],['outros','Suspensos e outros']
 ].map(([v,t])=>h('option',{value:v,selected:familia===v},t)));
 filtro.addEventListener('change',()=>{familia=filtro.value;renderLista();});
 const cards = filtrados.length ? h('ul',{class:'lista'},filtrados.map(a=>h('li',null,h('button',{class:'acorde-card',type:'button'},
   h('span',{class:'nome-acorde'},a.nome),h('span',{class:'tipo-acorde'},a.tipo),h('span',{class:'abrir'},'Ver posição e explicação ›')
  )))) : h('p',{class:'vazio'},'Nenhum acorde encontrado. Experimente buscar por C, Am, G ou mudar o filtro.');
 [...cards.querySelectorAll?.('.acorde-card')||[]].forEach((b,i)=>b.addEventListener('click',()=>renderDetalhe(filtrados[i])));
 app.replaceChildren(voltar(),h('h1',{tabindex:'-1'},'Dicionário de acordes'),h('p',{class:'sub'},'Encontre o acorde, veja o desenho e aprenda onde colocar cada dedo.'),
  h('div',{class:'filtros'},input,filtro),h('p',{class:'resultado'},`${filtrados.length} ${filtrados.length===1?'acorde disponível':'acordes disponíveis'}`),cards,
  h('p',{class:'nota-final'},'Dica: pressione as cordas perto do traste, sem colocar o dedo em cima da barrinha de metal.')); 
}
function renderDetalhe(a){
 const diagrama=diagramaAcorde({nome:a.nome,cordas:a.cordas,dedos:a.dedos});
 const posicoes=a.cordas.map((c,i)=>{
  const estado=c===-1?'Não toque':c===0?'Solta':`Casa ${c} · dedo ${a.dedos[i]}`;
  return h('li',null,h('strong',null,cordasNomes[i]),h('span',null,estado));
 });
 const dedoInfo=h('div',{class:'legenda'},h('span',null,'● Número dentro da bolinha = dedo usado'),h('span',null,'○ Corda solta'),h('span',null,'× Não tocar a corda'));
 const dicas=h('section',{class:'painel'},h('h2',null,'Como montar este acorde'),h('p',null,a.dica),h('ol',{class:'posicoes'},posicoes),
   h('p',{class:'lembrete'},'Dedos: 1 = indicador · 2 = médio · 3 = anelar · 4 = mínimo.'));
 const btn = h('button',{class:'btn',type:'button'},'← Voltar ao dicionário');btn.addEventListener('click',renderLista);
 app.replaceChildren(voltar(),h('button',{class:'voltar botao-voltar',type:'button'},'‹ Todos os acordes'),h('h1',{tabindex:'-1'},a.nome),h('p',{class:'sub'},a.tipo),
  h('section',{class:'painel visual'},h('p',{class:'rotulo'},'DIAGRAMA DO ACORDE'),diagrama, h('p',{class:'explica'},'Olhe o desenho de frente, como se o braço do violão estivesse em pé.'),h('div',{class:'guia-leitura'},h('h2',null,'Como ler o desenho'),h('p',null,'As linhas verticais representam as cordas: a 6ª corda, mais grossa, fica à esquerda; a 1ª, mais fina, fica à direita.'),h('p',null,'As linhas horizontais representam os trastes. A primeira linha de cima é a pestana; quando aparecer um número ao lado, ele indica a casa em que o desenho começa.'),h('p',null,'O número dentro de cada bolinha indica qual dedo usar: 1 indicador, 2 médio, 3 anelar e 4 mínimo. O símbolo ○ significa corda solta e × significa que a corda não deve ser tocada.')),dedoInfo),dicas,btn);
 app.querySelector('.botao-voltar').addEventListener('click',renderLista);
}
renderLista();
