// Posições padrão: cordas e dedos seguem da 6ª corda (mais grossa) à 1ª (mais fina).
export const acordes = [
 {nome:'A',tipo:'Maior',familia:'maior',cordas:[-1,0,2,2,2,0],dedos:[0,0,1,2,3,0],dica:'Aperte as três cordas do meio na 2ª casa, cada uma com um dedo. Deixe a 5ª e a 1ª cordas soltas.'},
 {nome:'C',tipo:'Maior',familia:'maior',cordas:[-1,3,2,0,1,0],dedos:[0,3,2,0,1,0],dica:'Use três dedos: 3ª casa da 5ª corda, 2ª casa da 4ª e 1ª casa da 2ª. Não toque a 6ª corda.'},
 {nome:'D',tipo:'Maior',familia:'maior',cordas:[-1,-1,0,2,3,2],dedos:[0,0,0,1,3,2],dica:'Monte um pequeno triângulo nas três cordas mais finas. Toque da 4ª corda para baixo.'},
 {nome:'E',tipo:'Maior',familia:'maior',cordas:[0,2,2,1,0,0],dedos:[0,2,3,1,0,0],dica:'Use três dedos nas 2ª, 2ª e 1ª casas das cordas 5, 4 e 3. As outras ficam soltas.'},
 {nome:'G',tipo:'Maior',familia:'maior',cordas:[3,2,0,0,0,3],dedos:[2,1,0,0,0,3],dica:'Coloque um dedo na 3ª casa da 6ª corda, outro na 2ª casa da 5ª e outro na 3ª casa da 1ª.'},
 {nome:'A menor (Am)',tipo:'Menor',familia:'menor',cordas:[-1,0,2,2,1,0],dedos:[0,0,2,3,1,0],dica:'É parecido com o E maior, mas os dedos ficam nas cordas 4, 3 e 2. Não toque a 6ª corda.'},
 {nome:'D menor (Dm)',tipo:'Menor',familia:'menor',cordas:[-1,-1,0,2,3,1],dedos:[0,0,0,2,3,1],dica:'Forme o triângulo nas três cordas mais finas. Toque apenas da 4ª corda para baixo.'},
 {nome:'E menor (Em)',tipo:'Menor',familia:'menor',cordas:[0,2,2,0,0,0],dedos:[0,2,3,0,0,0],dica:'Aperte a 5ª e a 4ª cordas na 2ª casa. Todas as outras ficam soltas.'},
 {nome:'F',tipo:'Maior simplificado',familia:'maior',cordas:[-1,-1,3,2,1,1],dedos:[0,0,3,2,1,1],dica:'Esta é uma versão simplificada: o indicador pressiona juntas as duas cordas mais finas na 1ª casa. Não toque as duas cordas mais grossas.'},
 {nome:'B menor (Bm)',tipo:'Menor com pestana',familia:'menor',cordas:[-1,2,4,4,3,2],dedos:[0,1,3,4,2,1],dica:'Faça a pestana com o indicador na 2ª casa, da 5ª à 1ª corda. Os outros dedos completam o desenho. Vá devagar; é um acorde mais difícil.'},
 {nome:'B7',tipo:'Sétima',familia:'setima',cordas:[-1,2,1,2,0,2],dedos:[0,2,1,3,0,4],dica:'Use quatro dedos: 5ª corda na 2ª casa, 4ª corda na 1ª casa, 3ª corda na 2ª casa e 1ª corda na 2ª casa. Toque da 5ª corda para baixo.'},
 {nome:'G7',tipo:'Sétima',familia:'setima',cordas:[3,2,0,0,0,1],dedos:[3,2,0,0,0,1],dica:'Coloque um dedo na 6ª corda, 3ª casa; outro na 5ª corda, 2ª casa; e o indicador na 1ª corda, 1ª casa. Toque todas as cordas.'},
 {nome:'A7',tipo:'Sétima',familia:'setima',cordas:[-1,0,2,0,2,0],dedos:[0,0,2,0,3,0],dica:'Aperte a 4ª e a 2ª cordas na 2ª casa. As demais cordas permitidas ficam soltas.'},
 {nome:'C7',tipo:'Sétima',familia:'setima',cordas:[-1,3,2,3,1,0],dedos:[0,3,2,4,1,0],dica:'Monte o C e acrescente o dedo mínimo na 3ª casa da 4ª corda.'},
 {nome:'D7',tipo:'Sétima',familia:'setima',cordas:[-1,-1,0,2,1,2],dedos:[0,0,0,2,1,3],dica:'Toque as quatro cordas mais finas. Os dedos ficam nas casas 2, 1 e 2.'},
 {nome:'E7',tipo:'Sétima',familia:'setima',cordas:[0,2,0,1,0,0],dedos:[0,2,0,1,0,0],dica:'É parecido com o E maior, mas retire o dedo da 4ª corda: ela fica solta.'},
 {nome:'Am7',tipo:'Menor com sétima',familia:'setima',cordas:[-1,0,2,0,1,0],dedos:[0,0,2,0,1,0],dica:'Parta do Am e solte o dedo que pressionaria a 3ª corda. A 4ª e a 2ª cordas permanecem pressionadas.'},
 {nome:'Em7',tipo:'Menor com sétima',familia:'setima',cordas:[0,2,0,0,0,0],dedos:[0,2,0,0,0,0],dica:'É como o Em, mas use apenas um dedo na 5ª corda, 2ª casa. Todas as outras ficam soltas.'},
 {nome:'Asus2',tipo:'Suspenso',familia:'outros',cordas:[-1,0,2,2,0,0],dedos:[0,0,1,2,0,0],dica:'Aperte a 4ª e a 3ª cordas na 2ª casa. As outras cordas permitidas ficam soltas.'},
 {nome:'Dsus4',tipo:'Suspenso',familia:'outros',cordas:[-1,-1,0,2,3,3],dedos:[0,0,0,1,3,4],dica:'Monte o D e acrescente o dedo mínimo na 3ª casa da 1ª corda.'}
];
