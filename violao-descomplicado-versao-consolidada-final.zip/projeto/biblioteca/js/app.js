import { diagramaAcorde } from '../../jornada/js/acordes.js';

const app = document.getElementById('app');
const NS = 'http://www.w3.org/2000/svg';
const h = (tag, props, ...children) => {
  const el = document.createElement(tag);
  for (const [key, value] of Object.entries(props || {})) {
    if (value == null || value === false) continue;
    if (key === 'class') el.className = value;
    else if (key === 'text') el.textContent = value;
    else el.setAttribute(key, value);
  }
  el.append(...children.flat().filter(x => x != null));
  return el;
};
let musicas = [];
let busca = '';
let nivel = 'todos';

async function carregar() {
  const r = await fetch('../dados/biblioteca-musicas.json');
  if (!r.ok) throw new Error('Não foi possível carregar as músicas.');
  const data = await r.json();
  musicas = data.musicas;
  renderLista();
}

function voltar() {
  return h('a', { class: 'voltar', href: '../' }, '‹ Início');
}
function cabecalho() {
  return [voltar(), h('h1', { tabindex: '-1' }, 'Biblioteca de músicas'),
    h('p', { class: 'sub' }, 'Cifras simples, acordes ilustrados e ritmos para praticar no seu tempo.')];
}
function renderLista() {
  const filtradas = musicas.filter(m => (nivel === 'todos' || m.nivel === nivel) &&
    (m.titulo + ' ' + m.descricao + ' ' + m.acordes.join(' ')).toLocaleLowerCase('pt-BR').includes(busca.toLocaleLowerCase('pt-BR')));
  const pesquisa = h('input', { type: 'search', placeholder: 'Buscar música ou acorde…', 'aria-label': 'Buscar música ou acorde', value: busca });
  pesquisa.addEventListener('input', () => { busca = pesquisa.value; renderLista(); const p = app.querySelector('input'); if (p) { p.focus(); p.setSelectionRange(busca.length, busca.length); } });
  const seletor = h('select', { 'aria-label': 'Filtrar por nível' },
    ...[['todos','Todos os níveis'],['iniciante','Iniciante'],['intermediario','Intermediário']].map(([v,t]) => h('option', { value:v, selected:nivel===v }, t)));
  seletor.addEventListener('change', () => { nivel = seletor.value; renderLista(); });
  const lista = filtradas.length ? h('ul', { class:'lista' }, filtradas.map(m => h('li', null,
    h('button', { class:'musica', type:'button' },
      h('h2', null, m.titulo), h('p', null, m.descricao),
      h('div', { class:'tags' }, h('span',{class:'tag'},m.nivel === 'iniciante' ? 'Iniciante' : 'Intermediário'),
        h('span',{class:'tag'},`${m.acordes.length} acordes`), h('span',{class:'tag'},`${m.bpm} BPM`), h('span',{class:'tag'},m.tipo))),
    )).map((li, i) => { li.querySelector('button').addEventListener('click', () => renderDetalhe(filtradas[i].id)); return li; }))
    : h('p', { class:'vazio' }, 'Nenhuma música encontrada. Tente outro nome ou acorde.');
  app.replaceChildren(...cabecalho(), h('div',{class:'filtros'},pesquisa,seletor),
    h('p',{class:'resultado'},`${filtradas.length} ${filtradas.length===1?'opção encontrada':'opções encontradas'}`), lista,
    h('p',{class:'sub',style:'margin-top:22px;font-size:.82rem'},'As peças desta biblioteca são estudos autorais criados para praticar cifras e ritmos.'));
}
function renderDetalhe(id) {
  const m = musicas.find(x => x.id === id);
  if (!m) return renderLista();
  const acordes = m.acordes.map(nome => {
    const dados = m.diagramas[nome];
    return h('figure',{class:'acorde-fig'},diagramaAcorde({nome,cordas:dados.cordas,dedos:dados.dedos}),h('figcaption',null,nome));
  });
  const cifra = h('div',{class:'cifra','aria-label':'Sequência de acordes'},m.sequencia.map((a,i)=>h('span',{title:`Compasso ${i+1}`},a)));
  const btnMetro = h('a',{class:'btn principal',href:'../metronomo/'},`Abrir metrônomo · ${m.bpm} BPM · ${m.compasso}/4`);
  btnMetro.addEventListener('click',()=>{try{localStorage.setItem('vd-metro',JSON.stringify({bpm:m.bpm,beats:m.compasso}));}catch(e){}});
  app.replaceChildren(voltar(),h('button',{class:'voltar',type:'button',style:'background:none;border:0;padding-left:12px'},'‹ Voltar à biblioteca'),
    h('h1',{tabindex:'-1'},m.titulo),h('p',{class:'sub'},m.descricao),
    h('section',{class:'painel'},h('strong',null,'Cifra simplificada'),cifra,
      h('p',{class:'sub'},`Repita a sequência na ordem. Cada acorde dura ${m.compasso} tempos (um compasso).`)),
    h('h2',null,'Acordes usados'),h('div',{class:'acordes'},acordes),
    h('h2',null,'Como tocar'),h('section',{class:'painel'},h('p',null,h('strong',null,'Ritmo: '),m.ritmo),
      h('p',null,h('strong',null,'Compasso: '),`${m.compasso}/4`),h('p',null,h('strong',null,'Velocidade inicial: '),`${m.bpm} BPM`),
      h('ol',{class:'passo'},m.passos.map(x=>h('li',null,x)))),
    h('p',{class:'dica'},`Dica: ${m.dica}`),btnMetro,
    h('button',{class:'btn',type:'button'},'Escolher outra música'));
  const botoes = app.querySelectorAll('button');
  botoes[0].addEventListener('click',renderLista);
  botoes[1].addEventListener('click',renderLista);
}

carregar().catch(() => app.replaceChildren(...cabecalho(),h('p',{class:'aviso'},'Não foi possível abrir a biblioteca. Verifique sua conexão e tente novamente.')));
