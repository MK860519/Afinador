import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const root=path.resolve(new URL('..',import.meta.url).pathname);
const read=p=>fs.readFileSync(path.join(root,p),'utf8');
test('R1. treinador oferece quatro padrões e orientações claras',()=>{
 const html=read('ritmos/index.html'),js=read('ritmos/ritmos.js');
 for(const id of ['pulso','alternada','balada','valsa']) assert.match(js,new RegExp(id));
 assert.match(html,/Treinador de Ritmos/);assert.match(js,/Para baixo/);assert.match(js,/Para cima/);
});
test('R2. controles de velocidade respeitam 40 a 160 BPM',()=>{
 const html=read('ritmos/index.html'),js=read('ritmos/ritmos.js');
 assert.match(html,/min="40" max="160"/);assert.match(js,/Math\.max\(40,Math\.min\(160/);
});
test('R3. treino tem áudio, indicador visual, pausa e preferências persistentes',()=>{
 const js=read('ritmos/ritmos.js');
 for(const s of ['AudioContext','setInterval','clearInterval','aria-pressed','vd-ritmos','visibilitychange']) assert.ok(js.includes(s),s);
});
test('R4. home e service worker integram o treinador ao app e ao offline',()=>{
 const home=read('index.html'),sw=read('sw.js');
 assert.match(home,/href="ritmos\/"/);for(const f of ['./ritmos/','./ritmos/index.html','./ritmos/ritmos.css','./ritmos/ritmos.js'])assert.ok(sw.includes(f),f);
});
