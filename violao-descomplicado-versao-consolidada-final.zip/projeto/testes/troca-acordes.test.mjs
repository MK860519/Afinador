import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const root=path.resolve(new URL('..',import.meta.url).pathname);
const read=p=>fs.readFileSync(path.join(root,p),'utf8');
test('T1. treinador oferece quatro exercícios progressivos com acordes existentes',()=>{
 const html=read('troca-acordes/index.html'),js=read('troca-acordes/troca.js'),dados=read('acordes/js/dados.js');
 for(const id of ['facil','basico','popular','desafio'])assert.ok(js.includes(id));
 for(const acorde of ["'Em'","'Am'","'C'","'G'","'D'","'F'"])assert.ok(js.includes(acorde),acorde);
 assert.match(html,/Treinador de Troca de Acordes/);assert.match(js,/diagramaAcorde/);assert.match(dados,/nome:'F'/);
});
test('T2. cada acorde permanece por quatro tempos antes da mudança',()=>{
 const js=read('troca-acordes/troca.js');assert.match(js,/if\(beat===4\)/);assert.match(js,/step=\(step\+1\)%seq\(\)\.length/);
});
test('T3. velocidade entre 40 e 120 BPM, áudio, pausa e preferências',()=>{
 const html=read('troca-acordes/index.html'),js=read('troca-acordes/troca.js');
 assert.match(html,/min="40" max="120"/);assert.match(js,/AudioContext/);assert.match(js,/clearInterval/);assert.match(js,/vd-troca-acordes/);assert.match(js,/visibilitychange/);
});
test('T4. treinador está no menu e no pré-cache offline com cache versionado',()=>{
 const home=read('index.html'),sw=read('sw.js');assert.match(home,/href="troca-acordes\/"/);
 for(const f of ['./troca-acordes/','./troca-acordes/index.html','./troca-acordes/troca.css','./troca-acordes/troca.js'])assert.ok(sw.includes(f),f);
 assert.match(sw,/const VERSION = 'v9'/);
});
test('T5. todos os caminhos locais usados pelos módulos existem',()=>{
 const html=read('troca-acordes/index.html'),js=read('troca-acordes/troca.js');
 for(const f of ['../css/base.css','../manifest.webmanifest','../icons/icon-192.png','../js/pwa.js'])assert.ok(fs.existsSync(path.join(root,'troca-acordes',f)),f);
 assert.ok(fs.existsSync(path.join(root,'acordes/js/dados.js')));assert.ok(fs.existsSync(path.join(root,'jornada/js/acordes.js')));
 assert.match(html,/type="module" src="troca.js"/);
});
