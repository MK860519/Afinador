import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const dados = fs.readFileSync(path.join(root,'acordes/js/dados.js'),'utf8');
const app = fs.readFileSync(path.join(root,'acordes/js/app.js'),'utf8');
const html = fs.readFileSync(path.join(root,'acordes/index.html'),'utf8');
const home = fs.readFileSync(path.join(root,'index.html'),'utf8');
const sw = fs.readFileSync(path.join(root,'sw.js'),'utf8');
test('A1. dicionário possui acordes de famílias variadas',()=>{
 for (const n of ['A','C','D','E','G','A menor (Am)','D menor (Dm)','E menor (Em)','B7','G7','A7','C7','D7','E7','B menor (Bm)','F','Asus2','Dsus4']) assert.ok(dados.includes(`nome:'${n}'`),`faltou ${n}`);
});
test('A2. cada diagrama tem seis cordas e seis dedos',()=>{
 const entries=[...dados.matchAll(/cordas:\[([^\]]+)\],dedos:\[([^\]]+)\]/g)];
 assert.ok(entries.length>=16);
 for(const [,c,d] of entries){const cs=c.split(',').map(Number),ds=d.split(',').map(Number);assert.equal(cs.length,6);assert.equal(ds.length,6);assert.ok(cs.every(x=>Number.isInteger(x)&&x>=-1&&x<=12));assert.ok(ds.every(x=>Number.isInteger(x)&&x>=0&&x<=4));}
});
test('A3. interface oferece busca, filtro e orientação de dedos',()=>{
 assert.match(app,/type:'search'/);assert.match(app,/addEventListener\('change'/);assert.match(app,/Como montar este acorde/);assert.match(app,/indicador/);
});
test('A4. entrada principal e service worker incluem o dicionário offline',()=>{
 assert.match(home,/href="acordes\/"/);assert.match(html,/js\/app\.js/);
 for(const f of ['./acordes/','./acordes/index.html','./acordes/acordes.css','./acordes/js/app.js','./acordes/js/dados.js']){assert.ok(sw.includes(`'${f}'`),`pré-cache ausente: ${f}`);assert.ok(fs.existsSync(path.join(root,f.slice(2))),`arquivo ausente: ${f}`);}
 assert.match(sw,/VERSION = 'v9'/);
});

test('A5. detalhe ensina a ler cordas, trastes, pestana e símbolos do diagrama',()=>{
 assert.match(app,/Como ler o desenho/);
 assert.match(app,/6ª corda, mais grossa, fica à esquerda/);
 assert.match(app,/linhas horizontais representam os trastes/);
 assert.match(app,/símbolo ○ significa corda solta e × significa/);
});
