import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const data = JSON.parse(fs.readFileSync(path.join(root, 'dados/biblioteca-musicas.json'), 'utf8'));
const sw = fs.readFileSync(path.join(root, 'sw.js'), 'utf8');

test('B1. biblioteca tem seis estudos identificados sem IDs repetidos', () => {
  assert.equal(data.musicas.length, 6);
  assert.equal(new Set(data.musicas.map(m => m.id)).size, data.musicas.length);
  for (const m of data.musicas) assert.match(m.id, /^[a-z0-9-]+$/);
});
test('B2. cada música tem conteúdo didático e sequência coerente', () => {
  for (const m of data.musicas) {
    assert.ok(m.titulo && m.descricao && m.ritmo && m.dica);
    assert.ok(m.passos.length >= 3);
    assert.ok(m.sequencia.length >= 3);
    assert.ok(m.sequencia.every(a => m.acordes.includes(a)));
    assert.ok(m.acordes.every(a => m.diagramas[a]));
  }
});
test('B3. diagramas de acordes têm seis cordas e seis dedos válidos', () => {
  for (const m of data.musicas) for (const nome of m.acordes) {
    const d = m.diagramas[nome];
    assert.equal(d.cordas.length, 6, `${m.id}: ${nome}`);
    assert.equal(d.dedos.length, 6, `${m.id}: ${nome}`);
    assert.ok(d.cordas.every(n => Number.isInteger(n) && n >= -1 && n <= 12));
    assert.ok(d.dedos.every(n => Number.isInteger(n) && n >= 0 && n <= 4));
  }
});
test('B4. BPM e compassos são compatíveis com o metrônomo', () => {
  for (const m of data.musicas) {
    assert.ok(m.bpm >= 40 && m.bpm <= 240);
    assert.ok([2,3,4].includes(m.compasso));
  }
});
test('B5. página, dados, CSS e JavaScript da biblioteca estão no pré-cache', () => {
  for (const asset of ['./biblioteca/','./biblioteca/index.html','./biblioteca/biblioteca.css','./biblioteca/js/app.js','./dados/biblioteca-musicas.json']) {
    assert.ok(sw.includes(`'${asset}'`), `faltou no pré-cache: ${asset}`);
    const local = path.join(root, asset.replace(/^\.\//,''));
    assert.ok(fs.existsSync(local), `arquivo inexistente: ${asset}`);
  }
});
test('B6. entrada principal oferece acesso à biblioteca', () => {
  const html = fs.readFileSync(path.join(root,'index.html'),'utf8');
  assert.match(html, /href="biblioteca\/"/);
  assert.match(html, /BIBLIOTECA DE MÚSICAS/);
});
